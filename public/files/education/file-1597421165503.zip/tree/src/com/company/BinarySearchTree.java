package com.company;

public class BinarySearchTree {
    //creating the root node
    public static Node root;

    //creation of the constructor
    public BinarySearchTree(){
        //the constructor sets the rood node to be null
        this.root = null;
    }
    //function to data into the binary search tree
    public void insert(int value){
        Node newNode = new Node(value);
        if(root==null){
            root = newNode;
            return;
        }
        Node current = root;
        Node parent = null;
        while(true){
            parent = current;
            if(value<current.data){
                current = current.left;
                if(current==null){
                    parent.left = newNode;
                    return;
                }
            }else{
                current = current.right;
                if(current==null){
                    parent.right = newNode;
                    return;
                }
            }
        }

    }
    public void printAscending(Node root){
        if(root!=null){
            printAscending(root.left);
            System.out.print(" "+root.data);
            printAscending(root.right);
        }
    }
    public void printDescending(Node root){
        if(root ==null){
            return;
        }
        if(root!=null){
            printDescending(root.right);
            System.out.print(" "+root.data);
            printDescending(root.left);
        }
    }
    public boolean find(Node root,int value){
        // Base Cases: root is null or
        if (root==null){
            System.out.println("Number not found");
            return false;
        }
        //value is present at root
        if(root.data==value){
            System.out.println("Number found in the tree");
            return true;
        }

        // value is greater than root's data
        if (root.data > value)
            return find(root.left,value);

        // val is less than root's data
        return find(root.right, value);

    }

    public int getDepth(Node root){
        if(root==null){
            //if the depth is 0
            return 0;
        }
        else{
            /* compute the depth of each subtree */
            int left_Depth = getDepth(root.left);
            int right_Depth = getDepth(root.right);

            //finding the subtree with the maximum depth
            if(left_Depth>right_Depth){
                return (left_Depth+1);
            }
            else{
                return (right_Depth+1);
                }
            }

        }
        public Node getParentNode(Node node, int value){
            if (node==null){
                return null;
            }
            Node parentNode = null;
            while(node!=null){
                if (value<node.data){
                    parentNode = node;
                    node=node.left;
                }else if(value>node.data){
                    parentNode = node;
                    node = node.right;
                }else
                    break;
            }
            return parentNode;
    }
    public Node getSiblingNode(Node node, int value){
        //getting the parent of the value
        Node parentNode = getParentNode(node,value);
        //Finding the sibling by comparing the value of the child
            if(value==parentNode.left.data){
                //if the left child is equal to the value, the the sibling is the right child
                return parentNode.right;
            }
            if(value==parentNode.right.data){
                //if the right child is equal to the value, the the sibling is the left child
                return parentNode.left;
            }
            //null is returned when there is no sibling to return 
            return null;
        }

        public void inorderParent(Node node,int value){
        Node parent = getParentNode(node, value);
        if(parent == null){
            System.out.println("Do not have parent");
            return;
        }
        if (parent.data >value){
            System.out.println("The inorder parent for "+ value +" is : "+parent.data);
        }
        else System.out.println("Do not have in order parent");

        }

        public Node delete(Node root, int value){

        //if the tree is empty, return the root
        if(root == null){
            return root;
        }
        //otherwise move down the tree
        if(value < root.data){
            root.left = delete(root.left,value);
        }
        else if(value > root.data){
            root.right = delete(root.left,value);
        }
        //if the value to be deleted is the sam eas the root's data,
        // then that is the node to be deleted
        else{
            // node with only one child or no child
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;

            // node with two children: Get the inorder successor (smallest
            // in the right subtree)
            root.data = minValue(root.right);

            // Delete the inorder successor
            root.right = delete(root.right, root.data);
        }
            return root;
        }

        int minValue(Node root){
        int min = root.data;

        while (root.left!=null){
            min = root.left.data;
            root = root.left;
        }
        return min;
        }
}
