package com.company;

public class Main {

    public static void main(String[] args) {
        BinarySearchTree tree = new BinarySearchTree();

        tree.insert(3);
        tree.insert(8);
        tree.insert(1);
        tree.insert(4);
        tree.insert(6);
        tree.insert(2);
        tree.insert(10);
        tree.insert(9);
        tree.insert(20);
        tree.insert(25);
        tree.insert(15);
        tree.insert(16);

        //tree.printAscending(tree.root);
        tree.printDescending(tree.root);

//
//        tree.find(tree.root, 30);
//
//      int depth =  tree.getDepth(tree.root);
//        System.out.println("The depth of the tree is "+depth);
//
//
//
//        //getting the sibling of a node
//        Node sibling_node = tree.getSiblingNode(tree.root, 9);
//        if(sibling_node == null){
//            System.out.println("Sibling do not exist");
//        }
//        else
//            System.out.println("The sibling is "+sibling_node.data);
//    }

    //getting the parent node

        tree.inorderParent(tree.root,3);
        tree.delete(tree.root,3);

        tree.printAscending(tree.root);

}
}
